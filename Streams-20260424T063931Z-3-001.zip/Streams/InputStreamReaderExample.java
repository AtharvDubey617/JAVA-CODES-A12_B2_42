import java.io.*;
class InputStreamReaderExample{
    public static void main(String[] args) throws IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        System.out.println("Enter First number: ");
        int a = Integer.parseInt(br.readLine());
        System.out.println("enter second number: ");
        int b= Integer.parseInt(br.readLine());
        if(a>b){
            System.out.println(a+"is greater");
        }else{
            System.out.println(b+"is greater");
        }
        br.close();
    }
}
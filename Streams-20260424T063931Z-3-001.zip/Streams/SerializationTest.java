import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Employee implements Serializable{
    private int code;
    private String name;
    private int salary;

    public Employee(int code, String name, int salary){
        this.code=code;
        this.name=name;
        this.salary=salary;
    }
    public Employee(){

    }
    @Override
    public String toString() {
        return "Employee [code=" + code + ", name=" + name + ", salary=" + salary + "]";
    }
}
public class SerializationTest {

    public static void main(String[] args) throws ClassNotFoundException,IOException{
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("jagu.ser"));
        Employee e1= new Employee(1001, "JAgruti", 3000000);
        oos.writeObject(e1);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("jagu.ser"));
        Employee e2 = new Employee();
        e2=(Employee) ois.readObject();
        System.out.println("Employee: "+e2);
        ois.close();
    }
}
